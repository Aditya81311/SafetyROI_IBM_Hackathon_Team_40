"""
Data ingestion + cleaning pipeline.

Loads the four source tables (accident counts, cause shares, mode
shares, age-band shares) plus city-level and seasonal tables, applies
standard cleaning (state-name normalization, year coercion, dedup),
and exposes a single `load_all()` used by `store.py`.

Real-data drop-in: put CSVs with the same filenames/columns in
`data_files/` (see seed_generator.py docstrings for exact schema) and
they'll be picked up automatically instead of the generated seed data.
"""

from __future__ import annotations

import pandas as pd

from app.data import seed_generator as sg
from app.data.reference import STATES

# Canonicalization map for common naming variants across MoRTH /
# data.gov.in releases (abbreviations, old names, punctuation).
_STATE_ALIASES = {
    "orissa": "Odisha",
    "pondicherry": "Puducherry",
    "uttaranchal": "Uttarakhand",
    "j&k": "Jammu and Kashmir",
    "jammu & kashmir": "Jammu and Kashmir",
    "nct of delhi": "Delhi",
    "delhi ut": "Delhi",
    "a & n islands": "Andaman and Nicobar Islands",
    "andaman & nicobar islands": "Andaman and Nicobar Islands",
    "telangana*": "Telangana",
}

_CANONICAL_LOOKUP = {s.strip().lower(): s for s in STATES}
_CANONICAL_LOOKUP.update(_STATE_ALIASES)


def standardize_state(name: str) -> str:
    if not isinstance(name, str):
        return name
    key = name.strip().lower()
    return _CANONICAL_LOOKUP.get(key, name.strip())


def _clean_common(df: pd.DataFrame, state_col: str = "state") -> pd.DataFrame:
    df = df.copy()
    df[state_col] = df[state_col].apply(standardize_state)
    if "year" in df.columns:
        df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
    df = df.dropna(subset=[state_col])
    df = df.drop_duplicates()
    return df


def load_accidents() -> pd.DataFrame:
    df = sg.generate_accidents_state_year()
    df = _clean_common(df)
    for col in ["accidents", "fatalities", "injuries", "population_lakhs"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["accidents"])
    df = df[df["state"].isin(STATES)]
    return df.reset_index(drop=True)


def load_causes() -> pd.DataFrame:
    df = sg.generate_causes_state_year()
    df = _clean_common(df)
    df["share"] = pd.to_numeric(df["share"], errors="coerce")
    df = df[df["state"].isin(STATES)]
    return df.reset_index(drop=True)


def load_modes() -> pd.DataFrame:
    df = sg.generate_modes_state_year()
    df = _clean_common(df)
    df["share"] = pd.to_numeric(df["share"], errors="coerce")
    df = df[df["state"].isin(STATES)]
    return df.reset_index(drop=True)


def load_age_vulnerability() -> pd.DataFrame:
    df = sg.generate_vulnerability_age_state_year()
    df = _clean_common(df)
    df["share"] = pd.to_numeric(df["share"], errors="coerce")
    df = df[df["state"].isin(STATES)]
    return df.reset_index(drop=True)


def load_city_accidents() -> pd.DataFrame:
    df = sg.generate_accidents_city_year()
    df = _clean_common(df)
    for col in ["accidents", "fatalities"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df[df["state"].isin(STATES)]
    return df.reset_index(drop=True)


def load_seasonal() -> pd.DataFrame:
    df = sg.generate_seasonal_state_month()
    df = _clean_common(df)
    df["relative_risk_index"] = pd.to_numeric(df["relative_risk_index"], errors="coerce")
    df = df[df["state"].isin(STATES)]
    return df.reset_index(drop=True)


def load_all() -> dict:
    """Loads and lightly cross-validates all sources, returns a dict
    of cleaned DataFrames keyed by table name."""
    accidents = load_accidents()
    causes = load_causes()
    modes = load_modes()
    age = load_age_vulnerability()
    city = load_city_accidents()
    seasonal = load_seasonal()

    # sanity check: cause shares per state/year should sum to ~1
    check = causes.groupby(["state", "year"])["share"].sum()
    bad = check[(check < 0.98) | (check > 1.02)]
    if len(bad) > 0:
        # normalize any drifted rows rather than failing the whole load
        causes = causes.copy()
        for (state, year) in bad.index:
            mask = (causes["state"] == state) & (causes["year"] == year)
            total = causes.loc[mask, "share"].sum()
            if total > 0:
                causes.loc[mask, "share"] = causes.loc[mask, "share"] / total

    return {
        "accidents": accidents,
        "causes": causes,
        "modes": modes,
        "age_vulnerability": age,
        "city_accidents": city,
        "seasonal": seasonal,
    }
