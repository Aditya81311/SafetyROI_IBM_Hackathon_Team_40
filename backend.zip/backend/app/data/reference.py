"""
Static reference tables used across the app.

These are *reference* datasets (population, city coordinates, the
cause->intervention knowledge base, literature-informed baseline
effectiveness figures). They are not accident records themselves —
those come from `seed_generator.py` / `ingestion.py`.

Population figures are approximate (Census 2011 projected / public
estimates) and only used as a denominator to normalize accident
counts into a rate. They are illustrative, not authoritative.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# States / UTs covered (kept to the major, commonly-reported set used in
# MoRTH "Road Accidents in India" state/UT tables).
# ---------------------------------------------------------------------------
STATES = [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
    "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
    "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
    "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan",
    "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh",
    "Uttarakhand", "West Bengal", "Delhi", "Jammu and Kashmir",
    "Puducherry", "Chandigarh",
]

# Approximate population in lakhs (100,000s) — used only to normalize
# accident counts into a per-capita rate. Rough public-estimate figures.
STATE_POPULATION_LAKHS = {
    "Andhra Pradesh": 530, "Arunachal Pradesh": 15, "Assam": 350,
    "Bihar": 1240, "Chhattisgarh": 300, "Goa": 16, "Gujarat": 700,
    "Haryana": 290, "Himachal Pradesh": 74, "Jharkhand": 380,
    "Karnataka": 670, "Kerala": 350, "Madhya Pradesh": 850,
    "Maharashtra": 1260, "Manipur": 32, "Meghalaya": 33, "Mizoram": 12,
    "Nagaland": 22, "Odisha": 460, "Punjab": 300, "Rajasthan": 810,
    "Sikkim": 7, "Tamil Nadu": 770, "Telangana": 380, "Tripura": 41,
    "Uttar Pradesh": 2380, "Uttarakhand": 115, "West Bengal": 1000,
    "Delhi": 205, "Jammu and Kashmir": 135, "Puducherry": 15,
    "Chandigarh": 12,
}

# A subset of major cities with static lat/long, used only for the
# optional "city markers on the map" advanced feature. Not a source of
# accident data — accident records stay at state/UT + city-year
# granularity as supplied.
CITY_COORDINATES = {
    "Delhi": (28.6139, 77.2090),
    "Mumbai": (19.0760, 72.8777),
    "Bengaluru": (12.9716, 77.5946),
    "Chennai": (13.0827, 80.2707),
    "Kolkata": (22.5726, 88.3639),
    "Hyderabad": (17.3850, 78.4867),
    "Pune": (18.5204, 73.8567),
    "Ahmedabad": (23.0225, 72.5714),
    "Jaipur": (26.9124, 75.7873),
    "Lucknow": (26.8467, 80.9462),
    "Kanpur": (26.4499, 80.3319),
    "Nagpur": (21.1458, 79.0882),
    "Indore": (22.7196, 75.8577),
    "Bhopal": (23.2599, 77.4126),
    "Patna": (25.5941, 85.1376),
    "Surat": (21.1702, 72.8311),
    "Coimbatore": (11.0168, 76.9558),
    "Guwahati": (26.1445, 91.7362),
    "Chandigarh": (30.7333, 76.7794),
    "Bhubaneswar": (20.2961, 85.8245),
}

CITY_TO_STATE = {
    "Delhi": "Delhi", "Mumbai": "Maharashtra", "Bengaluru": "Karnataka",
    "Chennai": "Tamil Nadu", "Kolkata": "West Bengal",
    "Hyderabad": "Telangana", "Pune": "Maharashtra",
    "Ahmedabad": "Gujarat", "Jaipur": "Rajasthan", "Lucknow": "Uttar Pradesh",
    "Kanpur": "Uttar Pradesh", "Nagpur": "Maharashtra", "Indore": "Madhya Pradesh",
    "Bhopal": "Madhya Pradesh", "Patna": "Bihar", "Surat": "Gujarat",
    "Coimbatore": "Tamil Nadu", "Guwahati": "Assam",
    "Chandigarh": "Chandigarh", "Bhubaneswar": "Odisha",
}

YEARS = [2018, 2019, 2020, 2021, 2022, 2023]

# ---------------------------------------------------------------------------
# Cause taxonomy (Dataset D — data.gov.in cause-wise accident data)
# ---------------------------------------------------------------------------
CAUSES = [
    "Over-speeding",
    "Drunk driving / Alcohol",
    "Distracted driving (mobile phone use)",
    "Signal / red-light jumping",
    "Wrong-side driving",
    "Poor road condition / engineering defect",
    "Adverse weather / low visibility",
    "Driver fatigue / sleep",
    "Vehicle defect (brakes/tyres)",
]

# Relative base weight (share of national accidents typically attributed
# to this cause) used to seed a plausible synthetic distribution. Roughly
# ordered per commonly reported MoRTH cause-wise splits (over-speeding
# dominant, weather/vehicle defect minor).
CAUSE_BASE_WEIGHT = {
    "Over-speeding": 0.32,
    "Drunk driving / Alcohol": 0.10,
    "Distracted driving (mobile phone use)": 0.12,
    "Signal / red-light jumping": 0.06,
    "Wrong-side driving": 0.09,
    "Poor road condition / engineering defect": 0.11,
    "Adverse weather / low visibility": 0.07,
    "Driver fatigue / sleep": 0.08,
    "Vehicle defect (brakes/tyres)": 0.05,
}

# ---------------------------------------------------------------------------
# Mode-of-transport taxonomy (Dataset E)
# ---------------------------------------------------------------------------
MODES_OF_TRANSPORT = [
    "Two-wheelers",
    "Cars/Jeeps/Taxis",
    "Auto-rickshaws",
    "Buses",
    "Trucks/Lorries",
    "Pedestrians",
    "Bicycles",
    "Other/Unspecified",
]

MODE_BASE_WEIGHT = {
    "Two-wheelers": 0.34,
    "Pedestrians": 0.18,
    "Cars/Jeeps/Taxis": 0.16,
    "Trucks/Lorries": 0.11,
    "Auto-rickshaws": 0.07,
    "Buses": 0.05,
    "Bicycles": 0.05,
    "Other/Unspecified": 0.04,
}

AGE_BANDS = ["0-17", "18-25", "26-35", "36-45", "46-60", "60+"]

AGE_BASE_WEIGHT = {
    "0-17": 0.05,
    "18-25": 0.28,
    "26-35": 0.26,
    "36-45": 0.18,
    "46-60": 0.15,
    "60+": 0.08,
}

MONTHS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]

# Multiplier applied to baseline monthly risk. >1 = elevated risk.
# Encodes commonly cited seasonal effects: monsoon (Jun-Sep) raises risk
# via wet/low-visibility roads, Oct-Nov festival travel & wedding season
# raises exposure, Dec-Jan raises risk in northern states via fog.
MONTH_RISK_MULTIPLIER = {
    "Jan": 1.05, "Feb": 0.95, "Mar": 0.95, "Apr": 0.95, "May": 1.00,
    "Jun": 1.10, "Jul": 1.15, "Aug": 1.12, "Sep": 1.08,
    "Oct": 1.15, "Nov": 1.20, "Dec": 1.10,
}

# States where winter fog materially adds to Dec/Jan risk (Indo-Gangetic
# plain) — used to add an extra bump for those states in those months.
FOG_BELT_STATES = {
    "Uttar Pradesh", "Punjab", "Haryana", "Bihar", "Delhi",
    "West Bengal", "Chandigarh", "Jharkhand",
}

# ---------------------------------------------------------------------------
# Cause -> Intervention knowledge base.
#
# `baseline_impact_pct` is a literature-informed, order-of-magnitude
# estimate of the % reduction in cause-linked crashes typically
# associated with the intervention (drawn from commonly cited road-safety
# engineering ranges, e.g. WHO / iRAP style figures). These are used as a
# *baseline* which is then adjusted per state using historical pattern
# comparison — see models/impact.py. They are NOT derived from a
# controlled experiment on this specific dataset.
#
# `cost_per_unit_lakhs` / `unit_description` feed the budget allocator —
# again illustrative reference costs, not procurement quotes.
# ---------------------------------------------------------------------------
INTERVENTION_CATALOG = {
    "Over-speeding": {
        "intervention": "Automated speed enforcement (speed cameras + radar)",
        "baseline_impact_pct": 22,
        "unit_description": "per 50 camera-enforced corridor points",
        "cost_per_unit_lakhs": 250,
    },
    "Drunk driving / Alcohol": {
        "intervention": "Sobriety checkpoints & random breath-testing drives",
        "baseline_impact_pct": 18,
        "unit_description": "per state-wide annual enforcement program",
        "cost_per_unit_lakhs": 120,
    },
    "Distracted driving (mobile phone use)": {
        "intervention": "Mobile-use enforcement + public awareness campaign",
        "baseline_impact_pct": 12,
        "unit_description": "per state-wide annual campaign + enforcement drive",
        "cost_per_unit_lakhs": 80,
    },
    "Signal / red-light jumping": {
        "intervention": "Red-light cameras & intersection redesign",
        "baseline_impact_pct": 20,
        "unit_description": "per 30 signalized intersections upgraded",
        "cost_per_unit_lakhs": 180,
    },
    "Wrong-side driving": {
        "intervention": "Median barriers & lane channelization",
        "baseline_impact_pct": 25,
        "unit_description": "per 100 km of divided-median retrofit",
        "cost_per_unit_lakhs": 600,
    },
    "Poor road condition / engineering defect": {
        "intervention": "Black-spot rectification & road infrastructure repair",
        "baseline_impact_pct": 28,
        "unit_description": "per 50 identified black-spots rectified",
        "cost_per_unit_lakhs": 400,
    },
    "Adverse weather / low visibility": {
        "intervention": "Improved signage, lighting & weather-warning systems",
        "baseline_impact_pct": 15,
        "unit_description": "per 100 km high-risk stretch upgraded",
        "cost_per_unit_lakhs": 150,
    },
    "Driver fatigue / sleep": {
        "intervention": "Mandated rest stops & driving-hour limits for commercial fleets",
        "baseline_impact_pct": 14,
        "unit_description": "per state-wide fleet compliance program",
        "cost_per_unit_lakhs": 90,
    },
    "Vehicle defect (brakes/tyres)": {
        "intervention": "Mandatory fitness certification & PUC enforcement drive",
        "baseline_impact_pct": 10,
        "unit_description": "per state-wide inspection enforcement drive",
        "cost_per_unit_lakhs": 70,
    },
}

RISK_WEIGHTS = {
    "accident_rate": 0.40,
    "fatality_rate": 0.40,
    "trend": 0.20,
}
