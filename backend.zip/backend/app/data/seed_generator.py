"""
Generates seed CSVs that mimic the *shape* of the real government
sources (MoRTH state/UT accident time-series, data.gov.in cause-wise
and mode-of-transport-wise tables, NCRB city-level 2023 data).

Why synthetic data at all: no dataset file was supplied with this
build request. Rather than block on that, this module produces
plausible, internally-consistent state/UT + year level data (accident
counts, fatalities, injuries, cause shares, mode shares, age-band
shares, monthly seasonality) with a fixed random seed so behaviour is
reproducible.

Swapping in the real datasets: `ingestion.py` reads CSVs from
`data_files/` with these exact column names. Drop in real MoRTH /
NCRB / data.gov.in extracts using the same column names and the seed
files are simply not generated / are overridden. See README for the
expected schema per file.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd

from app.data.reference import (
    AGE_BANDS,
    AGE_BASE_WEIGHT,
    CAUSE_BASE_WEIGHT,
    CAUSES,
    CITY_COORDINATES,
    CITY_TO_STATE,
    MODE_BASE_WEIGHT,
    MODES_OF_TRANSPORT,
    MONTH_RISK_MULTIPLIER,
    MONTHS,
    STATE_POPULATION_LAKHS,
    STATES,
    YEARS,
)

RNG_SEED = 42

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data_files")

ACCIDENTS_FILE = os.path.join(DATA_DIR, "accidents_state_year.csv")
CAUSES_FILE = os.path.join(DATA_DIR, "causes_state_year.csv")
MODES_FILE = os.path.join(DATA_DIR, "modes_state_year.csv")
AGE_FILE = os.path.join(DATA_DIR, "vulnerability_age_state_year.csv")
CITY_FILE = os.path.join(DATA_DIR, "accidents_city_year.csv")
SEASONAL_FILE = os.path.join(DATA_DIR, "seasonal_state_month.csv")


def _rng():
    return np.random.default_rng(RNG_SEED)


def _state_base_rate(rng, state: str) -> float:
    """Per-state baseline accidents per lakh population, with
    plausible spread so larger/denser states aren't just proportional
    to population."""
    # deterministic per-state jitter from a hash so re-runs are stable
    h = abs(hash(state)) % 1000 / 1000.0
    return 18 + h * 30  # roughly 18-48 accidents per lakh population


def generate_accidents_state_year(force: bool = False) -> pd.DataFrame:
    if os.path.exists(ACCIDENTS_FILE) and not force:
        return pd.read_csv(ACCIDENTS_FILE)

    rng = _rng()
    rows = []
    for state in STATES:
        pop_lakhs = STATE_POPULATION_LAKHS[state]
        base_rate = _state_base_rate(rng, state)
        # random state-level trend direction: most states improving
        # slightly (national trend is a slow decline in accident rate
        # even as fatalities stay high), a minority worsening.
        trend_pct = rng.normal(loc=-1.5, scale=4.0)  # % change per year
        fatality_ratio_base = rng.uniform(0.28, 0.42)  # fatalities per accident

        accidents_prev = base_rate * pop_lakhs
        for i, year in enumerate(YEARS):
            noise = rng.normal(1.0, 0.05)
            if i == 0:
                accidents = accidents_prev * noise
            else:
                accidents = accidents_prev * (1 + trend_pct / 100.0) * noise
            accidents = max(accidents, 50)

            # COVID dip in 2020, partial rebound 2021 — matches the
            # widely reported real-world pattern, keeps the synthetic
            # series from looking naive.
            if year == 2020:
                accidents *= 0.72
            elif year == 2021:
                accidents *= 0.88

            fatality_ratio = max(0.15, fatality_ratio_base + rng.normal(0, 0.02))
            fatalities = accidents * fatality_ratio
            injuries = accidents * rng.uniform(0.85, 1.15)

            rows.append({
                "state": state,
                "year": year,
                "accidents": round(accidents),
                "fatalities": round(fatalities),
                "injuries": round(injuries),
                "population_lakhs": pop_lakhs,
            })
            accidents_prev = accidents

    df = pd.DataFrame(rows)
    os.makedirs(DATA_DIR, exist_ok=True)
    df.to_csv(ACCIDENTS_FILE, index=False)
    return df


def generate_causes_state_year(force: bool = False) -> pd.DataFrame:
    if os.path.exists(CAUSES_FILE) and not force:
        return pd.read_csv(CAUSES_FILE)

    rng = _rng()
    rows = []
    for state in STATES:
        # perturb the national base weights per state via a Dirichlet
        # draw centered on the base weights, so each state has a
        # distinct-but-plausible cause profile.
        base = np.array([CAUSE_BASE_WEIGHT[c] for c in CAUSES])
        concentration = base * 60  # higher = closer to the base profile
        state_weights = rng.dirichlet(concentration)
        for year in YEARS:
            year_noise = rng.dirichlet(state_weights * 200)
            for cause, share in zip(CAUSES, year_noise):
                rows.append({
                    "state": state,
                    "year": year,
                    "cause": cause,
                    "share": round(float(share), 4),
                })
    df = pd.DataFrame(rows)
    os.makedirs(DATA_DIR, exist_ok=True)
    df.to_csv(CAUSES_FILE, index=False)
    return df


def generate_modes_state_year(force: bool = False) -> pd.DataFrame:
    if os.path.exists(MODES_FILE) and not force:
        return pd.read_csv(MODES_FILE)

    rng = _rng()
    rows = []
    for state in STATES:
        base = np.array([MODE_BASE_WEIGHT[m] for m in MODES_OF_TRANSPORT])
        concentration = base * 60
        state_weights = rng.dirichlet(concentration)
        for year in YEARS:
            year_noise = rng.dirichlet(state_weights * 200)
            for mode, share in zip(MODES_OF_TRANSPORT, year_noise):
                rows.append({
                    "state": state,
                    "year": year,
                    "mode": mode,
                    "share": round(float(share), 4),
                })
    df = pd.DataFrame(rows)
    os.makedirs(DATA_DIR, exist_ok=True)
    df.to_csv(MODES_FILE, index=False)
    return df


def generate_vulnerability_age_state_year(force: bool = False) -> pd.DataFrame:
    if os.path.exists(AGE_FILE) and not force:
        return pd.read_csv(AGE_FILE)

    rng = _rng()
    rows = []
    for state in STATES:
        base = np.array([AGE_BASE_WEIGHT[a] for a in AGE_BANDS])
        concentration = base * 80
        state_weights = rng.dirichlet(concentration)
        for year in YEARS:
            year_noise = rng.dirichlet(state_weights * 250)
            for band, share in zip(AGE_BANDS, year_noise):
                rows.append({
                    "state": state,
                    "year": year,
                    "age_band": band,
                    "share": round(float(share), 4),
                })
    df = pd.DataFrame(rows)
    os.makedirs(DATA_DIR, exist_ok=True)
    df.to_csv(AGE_FILE, index=False)
    return df


def generate_accidents_city_year(force: bool = False) -> pd.DataFrame:
    """NCRB-style city-level accident data for the major cities we
    have coordinates for."""
    if os.path.exists(CITY_FILE) and not force:
        return pd.read_csv(CITY_FILE)

    rng = _rng()
    rows = []
    for city, state in CITY_TO_STATE.items():
        base = 3000 + (abs(hash(city)) % 5000)
        prev = base
        for i, year in enumerate(YEARS):
            noise = rng.normal(1.0, 0.06)
            trend = rng.normal(-1.0, 3.0) / 100.0
            val = prev * (1 + trend) * noise if i > 0 else prev * noise
            if year == 2020:
                val *= 0.68
            elif year == 2021:
                val *= 0.85
            val = max(val, 200)
            fatalities = val * rng.uniform(0.18, 0.30)
            rows.append({
                "city": city,
                "state": state,
                "year": year,
                "accidents": round(val),
                "fatalities": round(fatalities),
            })
            prev = val
    df = pd.DataFrame(rows)
    os.makedirs(DATA_DIR, exist_ok=True)
    df.to_csv(CITY_FILE, index=False)
    return df


def generate_seasonal_state_month(force: bool = False) -> pd.DataFrame:
    """Synthetic month-level relative risk index per state, used for
    the seasonal/temporal-risk advanced feature. Real MoRTH/NCRB
    releases are annual, so month-level granularity is modeled here
    from known seasonal effects (monsoon, festival travel, winter fog)
    rather than sourced directly — flagged as such in the API
    metadata."""
    if os.path.exists(SEASONAL_FILE) and not force:
        return pd.read_csv(SEASONAL_FILE)

    from app.data.reference import FOG_BELT_STATES

    rng = _rng()
    rows = []
    for state in STATES:
        state_jitter = rng.normal(1.0, 0.03, size=len(MONTHS))
        for month, jitter in zip(MONTHS, state_jitter):
            multiplier = MONTH_RISK_MULTIPLIER[month] * jitter
            if state in FOG_BELT_STATES and month in ("Dec", "Jan"):
                multiplier *= 1.12
            rows.append({
                "state": state,
                "month": month,
                "relative_risk_index": round(float(multiplier), 3),
            })
    df = pd.DataFrame(rows)
    os.makedirs(DATA_DIR, exist_ok=True)
    df.to_csv(SEASONAL_FILE, index=False)
    return df


def generate_all(force: bool = False) -> None:
    generate_accidents_state_year(force)
    generate_causes_state_year(force)
    generate_modes_state_year(force)
    generate_vulnerability_age_state_year(force)
    generate_accidents_city_year(force)
    generate_seasonal_state_month(force)


if __name__ == "__main__":
    generate_all(force=True)
    print(f"Seed data written to {DATA_DIR}")
