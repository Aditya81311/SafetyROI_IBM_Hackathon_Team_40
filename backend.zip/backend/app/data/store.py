"""
In-memory data store. Loaded once at application startup (see
app/main.py's startup event) and reused by every request — this is a
read-heavy analytics API over a small, batch-refreshed dataset, so a
DB is unnecessary overhead for hackathon scope. Swap `refresh()` for a
DB-backed loader later without touching the API layer.
"""

from __future__ import annotations

import threading

from app.data.ingestion import load_all


class DataStore:
    def __init__(self):
        self._lock = threading.Lock()
        self._tables: dict = {}
        self._loaded = False

    def refresh(self):
        with self._lock:
            self._tables = load_all()
            self._loaded = True

    @property
    def loaded(self) -> bool:
        return self._loaded

    @property
    def accidents(self):
        self._ensure()
        return self._tables["accidents"]

    @property
    def causes(self):
        self._ensure()
        return self._tables["causes"]

    @property
    def modes(self):
        self._ensure()
        return self._tables["modes"]

    @property
    def age_vulnerability(self):
        self._ensure()
        return self._tables["age_vulnerability"]

    @property
    def city_accidents(self):
        self._ensure()
        return self._tables["city_accidents"]

    @property
    def seasonal(self):
        self._ensure()
        return self._tables["seasonal"]

    def _ensure(self):
        if not self._loaded:
            self.refresh()


store = DataStore()
