"""
Basic smoke tests hitting every route once. Requires the real
dependencies (fastapi, uvicorn, plotly) installed — this sandbox that
built the backend could not install them offline, so run these
yourself after `pip install -r requirements.txt`:

    pytest tests/test_smoke.py -v
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


@pytest.fixture(scope="module", autouse=True)
def _load_data():
    from app.data.store import store
    store.refresh()


def test_root():
    assert client.get("/").status_code == 200


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["data_loaded"] is True


def test_meta_states():
    r = client.get("/api/meta/states")
    assert r.status_code == 200
    body = r.json()
    assert "states" in body and len(body["states"]) > 10


def test_meta_summary():
    assert client.get("/api/meta/summary").status_code == 200


def test_risk_scores():
    r = client.get("/api/risk-scores")
    assert r.status_code == 200
    body = r.json()
    assert "results" in body and len(body["results"]) > 0
    assert "formula" in body


def test_risk_scores_html():
    r = client.get("/api/risk-scores?format=html")
    assert r.status_code == 200
    assert "risk-scores" in r.text


def test_risk_map():
    r = client.get("/api/risk-map")
    assert r.status_code == 200
    assert "html" in r.json()


def _sample_state():
    return client.get("/api/meta/states").json()["states"][0]


def test_causes():
    state = _sample_state()
    r = client.get(f"/api/causes/{state}")
    assert r.status_code == 200
    assert "breakdown" in r.json()


def test_forecast():
    state = _sample_state()
    r = client.get(f"/api/forecast/{state}")
    assert r.status_code == 200
    assert "forecast" in r.json()


def test_interventions():
    state = _sample_state()
    r = client.get(f"/api/interventions/{state}")
    assert r.status_code == 200
    assert len(r.json()["recommendations"]) >= 3


def test_impact_estimate():
    state = _sample_state()
    r = client.get(f"/api/impact-estimate/{state}")
    assert r.status_code == 200
    assert "disclosure" in r.json()


def test_vulnerability():
    state = _sample_state()
    r = client.get(f"/api/vulnerability/{state}")
    assert r.status_code == 200


def test_seasonal_risk():
    state = _sample_state()
    r = client.get(f"/api/seasonal-risk/{state}")
    assert r.status_code == 200
    assert "high_risk_months" in r.json()


def test_allocate_budget():
    r = client.post("/api/allocate-budget", json={"total_budget_lakhs": 2000})
    assert r.status_code == 200
    body = r.json()
    assert body["total_cost_used_lakhs"] <= 2000
    assert len(body["allocations"]) > 0


def test_unknown_state_404():
    r = client.get("/api/causes/Atlantis")
    assert r.status_code == 404


def test_bad_budget_rejected():
    r = client.post("/api/allocate-budget", json={"total_budget_lakhs": -5})
    assert r.status_code == 422
